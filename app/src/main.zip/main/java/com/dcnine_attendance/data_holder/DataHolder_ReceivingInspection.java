package com.dcnine_attendance.data_holder;

import java.util.ArrayList;

/**
 * Created by nitinb on 10-02-2016.
 */
public class DataHolder_ReceivingInspection {

    private static DataHolder_ReceivingInspection dataObject = null;


    public DataHolder_ReceivingInspection() {
        // left blank intentionally
    }

    public static DataHolder_ReceivingInspection getInstance() {
        if (dataObject == null)
            dataObject = new DataHolder_ReceivingInspection();
        return dataObject;
    }




    public String di_pick_date;
    public String receivingMaterial_pick_date;

    public String getDi_pick_date() {
        return di_pick_date;
    }

    public void setDi_pick_date(String di_pick_date) {
        this.di_pick_date = di_pick_date;
    }

    public String getReceivingMaterial_pick_date() {
        return receivingMaterial_pick_date;
    }

    public void setReceivingMaterial_pick_date(String receivingMaterial_pick_date) {
        this.receivingMaterial_pick_date = receivingMaterial_pick_date;
    }

    public String str_remark;
    public String camera_lat;
    public String camera_long;
    public String camera_time;


    public String getCamera_lat() {
        return camera_lat;
    }

    public void setCamera_lat(String camera_lat) {
        this.camera_lat = camera_lat;
    }

    public String getCamera_long() {
        return camera_long;
    }

    public void setCamera_long(String camera_long) {
        this.camera_long = camera_long;
    }

    public String getCamera_time() {
        return camera_time;
    }

    public void setCamera_time(String camera_time) {
        this.camera_time = camera_time;
    }

    public String getStr_remark() {
        return str_remark;
    }

    public void setStr_remark(String str_remark) {
        this.str_remark = str_remark;
    }

    public static DataHolder_ReceivingInspection getDataObject() {
        return dataObject;
    }

    public static void setDataObject(DataHolder_ReceivingInspection dataObject) {
        DataHolder_ReceivingInspection.dataObject = dataObject;
    }


    private String imgbitmap1;
    private String imgbitmap2;
    private String imgbitmap3;
    private String imgbitmap4;
    private String imgbitmap5;
    private String imglrgbitmap1;
    private String imglrgbitmap2;
    private String imglrgbitmap3;
    private String imglrgbitmap4;
    private String imglrgbitmap5;

    private String imageNmae1;
    private String imageNmae2;
    private String imageNmae3;

    public String getImageNmae1() {
        return imageNmae1;
    }

    public void setImageNmae1(String imageNmae1) {
        this.imageNmae1 = imageNmae1;
    }

    public String getImageNmae2() {
        return imageNmae2;
    }

    public void setImageNmae2(String imageNmae2) {
        this.imageNmae2 = imageNmae2;
    }

    public String getImageNmae3() {
        return imageNmae3;
    }

    public void setImageNmae3(String imageNmae3) {
        this.imageNmae3 = imageNmae3;
    }

    public String getImageNmae4() {
        return imageNmae4;
    }

    public void setImageNmae4(String imageNmae4) {
        this.imageNmae4 = imageNmae4;
    }

    public String getImageNmae5() {
        return imageNmae5;
    }

    public void setImageNmae5(String imageNmae5) {
        this.imageNmae5 = imageNmae5;
    }

    private String imageNmae4;
    private String imageNmae5;


    public void setImg1(String imgbitmap1) {
        this.imgbitmap1 = imgbitmap1;
    }
    public void setImg2(String imgbitmap2) {
        this.imgbitmap2 = imgbitmap2;
    }
    public void setImg3(String imgbitmap3) {
        this.imgbitmap3 = imgbitmap3;
    }
    public String getImg1() {
        return imgbitmap1;
    }
    public String getImg2() {
        return imgbitmap2;
    }
    public String getImg3() {
        return imgbitmap3;
    }

    public void setImg4(String imgbitmap4) {
        this.imgbitmap4 = imgbitmap4;
    }

    public void setImg5(String imgbitmap5) {
        this.imgbitmap5 = imgbitmap5;
    }

    public String getImg4() {
        return imgbitmap4;
    }

    public String getImg5() {
        return imgbitmap5;
    }



    public void setlrgImg1(String imglrgbitmap1) {
        this.imglrgbitmap1 = imglrgbitmap1;
    }

    public void setlrgImg2(String imglrgbitmap2) {
        this.imglrgbitmap2 = imglrgbitmap2;
    }

    public void setlrgImg3(String imglrgbitmap3) {
        this.imglrgbitmap3 = imglrgbitmap3;
    }

    public void setlrgImg4(String imglrgbitmap4) {
        this.imglrgbitmap4 = imglrgbitmap4;
    }

    public void setlrgImg5(String imglrgbitmap5) {
        this.imglrgbitmap5 = imglrgbitmap5;
    }

    public String getlrgImg1() {
        return imglrgbitmap1;
    }

    public String getlrgImg2() {
        return imglrgbitmap2;
    }

    public String getlrgImg3() {
        return imglrgbitmap3;
    }

    public String getlrgImg4() {
        return imglrgbitmap4;
    }

    public String getlrgImg5() {
        return imglrgbitmap5;
    }

    private String project_id;
    private String geographic_id;
    private String subareaone_id;
    private String receipt_number;
    private String open_general_purchase;
    private String factory_store_id;
    private String scheme_id;
    private String store_rsp;

    public String getStore_rsp() {
        return store_rsp;
    }

    public void setStore_rsp(String store_rsp) {
        this.store_rsp = store_rsp;
    }

    public String getScheme_id() {
        return scheme_id;
    }

    public void setScheme_id(String scheme_id) {
        this.scheme_id = scheme_id;
    }

    public String getFactory_store_id() {
        return factory_store_id;
    }

    public void setFactory_store_id(String factory_store_id) {
        this.factory_store_id = factory_store_id;
    }

    public String getOpen_general_purchase() {
        return open_general_purchase;
    }

    public void setOpen_general_purchase(String open_general_purchase) {
        this.open_general_purchase = open_general_purchase;
    }

    public String getReceipt_number() {
        return receipt_number;
    }

    public void setReceipt_number(String receipt_number) {
        this.receipt_number = receipt_number;
    }

    public String getGeographic_id() {
        return geographic_id;
    }

    public void setGeographic_id(String geographic_id) {
        this.geographic_id = geographic_id;
    }

    public String getSubareaone_id() {
        return subareaone_id;
    }

    public void setSubareaone_id(String subareaone_id) {
        this.subareaone_id = subareaone_id;
    }

    private String tkc_id;

    public String getProject_id() {
        return project_id;
    }

    public void setProject_id(String project_id) {
        this.project_id = project_id;
    }

    public String getTkc_id() {
        return tkc_id;
    }

    public void setTkc_id(String tkc_id) {
        this.tkc_id = tkc_id;
    }

    public String getTkcResp_id() {
        return tkcResp_id;
    }

    public void setTkcResp_id(String tkcResp_id) {
        this.tkcResp_id = tkcResp_id;
    }

    public String getUtility_id() {
        return utility_id;
    }

    public void setUtility_id(String utility_id) {
        this.utility_id = utility_id;
    }

    public String getVendorName_id() {
        return vendorName_id;
    }

    public void setVendorName_id(String vendorName_id) {
        this.vendorName_id = vendorName_id;
    }

    public String getDiNumber_id() {
        return diNumber_id;
    }

    public void setDiNumber_id(String diNumber_id) {
        this.diNumber_id = diNumber_id;
    }

    public String getItem_id() {
        return item_id;
    }

    public void setItem_id(String item_id) {
        this.item_id = item_id;
    }

    public String getLotNo_id() {
        return lotNo_id;
    }

    public void setLotNo_id(String lotNo_id) {
        this.lotNo_id = lotNo_id;
    }

    public String getDiQuantity_id() {
        return diQuantity_id;
    }

    public void setDiQuantity_id(String diQuantity_id) {
        this.diQuantity_id = diQuantity_id;
    }

    public String getQuantityReceived_id() {
        return quantityReceived_id;
    }

    public void setQuantityReceived_id(String quantityReceived_id) {
        this.quantityReceived_id = quantityReceived_id;
    }

    public String getQuantityPassed_id() {
        return quantityPassed_id;
    }

    public void setQuantityPassed_id(String quantityPassed_id) {
        this.quantityPassed_id = quantityPassed_id;
    }

    private String tkcResp_id;
    private String utility_id;
    private String vendorName_id;
    private String diNumber_id;


    private String lotNo_id;
    private String diQuantity_id;
    private String quantityReceived_id;
    private String quantityPassed_id;
    private String factory_insp_id;

    private String insp_id;
    private String other_resp;
    private String vehicle_no;

    public String getVehicle_no() {
        return vehicle_no;
    }

    public void setVehicle_no(String vehicle_no) {
        this.vehicle_no = vehicle_no;
    }

    public String getOther_resp() {
        return other_resp;
    }

    public void setOther_resp(String other_resp) {
        this.other_resp = other_resp;
    }

    public String getStore_id() {
        return store_id;
    }

    public void setStore_id(String store_id) {
        this.store_id = store_id;
    }

    public String getInsp_id() {
        return insp_id;
    }

    public void setInsp_id(String insp_id) {
        this.insp_id = insp_id;
    }

    public String getFactory_insp_id() {
        return factory_insp_id;
    }

    public void setFactory_insp_id(String factory_insp_id) {
        this.factory_insp_id = factory_insp_id;
    }

    private String str_mainItem;

    public String getStr_mainItem() {
        return str_mainItem;
    }

    public void setStr_mainItem(String str_mainItem) {
        this.str_mainItem = str_mainItem;
    }

    public String receiving_item;

    private ArrayList<String> receivingselecteditem;
    public void setreceivingselecteditem(ArrayList<String> selectedStrings) {
        this.receivingselecteditem = selectedStrings;
    }

    public ArrayList<String> getreceivingselecteditem() {
        return receivingselecteditem;
    }

    public String getReceiving_item() {
        return receiving_item;
    }

    public void setReceiving_item(String receiving_item) {
        this.receiving_item = receiving_item;
    }

    private String common_item;

    public String getCommon_item() {
        return common_item;
    }

    public void setCommon_item(String common_item) {
        this.common_item = common_item;
    }

    private String str_pole;
    private String str_dt;
    private String str_conductor;
    private String str_cable;



    public String getStr_pole() {
        return str_pole;
    }

    public void setStr_pole(String str_pole) {
        this.str_pole = str_pole;
    }

    public String getStr_dt() {
        return str_dt;
    }

    public void setStr_dt(String str_dt) {
        this.str_dt = str_dt;
    }

    public String getStr_conductor() {
        return str_conductor;
    }

    public void setStr_conductor(String str_conductor) {
        this.str_conductor = str_conductor;
    }

    public String getStr_cable() {
        return str_cable;
    }

    public void setStr_cable(String str_cable) {
        this.str_cable = str_cable;
    }

    public String getStr_metering() {
        return str_metering;
    }

    public void setStr_metering(String str_metering) {
        this.str_metering = str_metering;
    }

    public String getStr_substation() {
        return str_substation;
    }

    public void setStr_substation(String str_substation) {
        this.str_substation = str_substation;
    }

    private String str_metering;
    private String str_substation;

    public String city_id;
    public String receiving_from;
    public String mzone_id;
    public String mcity_id;
    public String store_id;
    public String item_id;
    public String qty_doc;
    public String qty_rec;
    public String qty_damaged;
    public String qty_accepted;
    public String grn_transfer_no;
    public String qty_transfer;
    public String vendor_id;

    public String in_out_id;
    public String g_c_junction;
    public String issue_id;
    public String other_issue;
    public String junction_id;

    public String getJunction_id() {
        return junction_id;
    }

    public void setJunction_id(String junction_id) {
        this.junction_id = junction_id;
    }

    public String getIn_out_id() {
        return in_out_id;
    }

    public void setIn_out_id(String in_out_id) {
        this.in_out_id = in_out_id;
    }

    public String getG_c_junction() {
        return g_c_junction;
    }

    public void setG_c_junction(String g_c_junction) {
        this.g_c_junction = g_c_junction;
    }

    public String getIssue_id() {
        return issue_id;
    }

    public void setIssue_id(String issue_id) {
        this.issue_id = issue_id;
    }

    public String getOther_issue() {
        return other_issue;
    }

    public void setOther_issue(String other_issue) {
        this.other_issue = other_issue;
    }

    public String getVendor_id() {
        return vendor_id;
    }

    public void setVendor_id(String vendor_id) {
        this.vendor_id = vendor_id;
    }

    public String getQty_transfer() {
        return qty_transfer;
    }

    public void setQty_transfer(String qty_transfer) {
        this.qty_transfer = qty_transfer;
    }

    public String getGrn_transfer_no() {
        return grn_transfer_no;
    }

    public void setGrn_transfer_no(String grn_transfer_no) {
        this.grn_transfer_no = grn_transfer_no;
    }

    public String getCity_id() {
        return city_id;
    }

    public void setCity_id(String city_id) {
        this.city_id = city_id;
    }

    public String getReceiving_from() {
        return receiving_from;
    }

    public void setReceiving_from(String receiving_from) {
        this.receiving_from = receiving_from;
    }

    public String getMzone_id() {
        return mzone_id;
    }

    public void setMzone_id(String mzone_id) {
        this.mzone_id = mzone_id;
    }

    public String getMcity_id() {
        return mcity_id;
    }

    public void setMcity_id(String mcity_id) {
        this.mcity_id = mcity_id;
    }

    public String getQty_doc() {
        return qty_doc;
    }

    public void setQty_doc(String qty_doc) {
        this.qty_doc = qty_doc;
    }

    public String getQty_rec() {
        return qty_rec;
    }

    public void setQty_rec(String qty_rec) {
        this.qty_rec = qty_rec;
    }

    public String getQty_damaged() {
        return qty_damaged;
    }

    public void setQty_damaged(String qty_damaged) {
        this.qty_damaged = qty_damaged;
    }

    public String getQty_accepted() {
        return qty_accepted;
    }

    public void setQty_accepted(String qty_accepted) {
        this.qty_accepted = qty_accepted;
    }

    public void nullify_DataHolder_ReceivingInspection_next() {

        dataObject=null;

        str_pole=null;
        str_dt=null;
        str_conductor=null;
        str_cable=null;
        str_metering=null;
        str_substation=null;

         diQuantity_id=null;
         quantityReceived_id=null;
         quantityPassed_id=null;

        imgbitmap1=null;
        imgbitmap2=null;
        imgbitmap3=null;
        imgbitmap4=null;
        imgbitmap5=null;

        imglrgbitmap1=null;
        imglrgbitmap2=null;
        imglrgbitmap3=null;
        imglrgbitmap4=null;
        imglrgbitmap5=null;

        imageNmae1= null;
        imageNmae2= null;
        imageNmae3= null;
        imageNmae4= null;
        imageNmae5= null;

    }


    public void nullify_DataHolder_ReceivingInspection() {

        dataObject=null;

        city_id=null;
        receiving_from=null;
        vendor_id=null;
        mzone_id=null;
        mcity_id=null;
        store_id=null;
        item_id=null;

        qty_doc=null;
        qty_rec=null;
        qty_damaged=null;
        qty_accepted=null;
        grn_transfer_no=null;
        str_remark=null;


        in_out_id=null;
        city_id=null;
        g_c_junction=null;
        junction_id=null;
        issue_id=null;
        other_issue=null;

        imgbitmap1=null;
        imgbitmap2=null;
        imgbitmap3=null;
        imgbitmap4=null;
        imgbitmap5=null;

        imglrgbitmap1=null;
        imglrgbitmap2=null;
        imglrgbitmap3=null;
        imglrgbitmap4=null;
        imglrgbitmap5=null;

        imageNmae1= null;
        imageNmae2= null;
        imageNmae3= null;
        imageNmae4= null;
        imageNmae5= null;

    }





}
