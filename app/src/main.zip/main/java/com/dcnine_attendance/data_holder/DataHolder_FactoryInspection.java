package com.dcnine_attendance.data_holder;

import java.util.ArrayList;

/**
 * Created by nitinb on 10-02-2016.
 */
public class DataHolder_FactoryInspection {

    private static DataHolder_FactoryInspection dataObject = null;


    public DataHolder_FactoryInspection() {
        // left blank intentionally
    }

    public static DataHolder_FactoryInspection getInstance() {
        if (dataObject == null)
            dataObject = new DataHolder_FactoryInspection();
        return dataObject;
    }



    private ArrayList<String> selectedStrings;
    public void setSelectedStrings(ArrayList<String> selectedStrings) {
        this.selectedStrings = selectedStrings;
    }

    public ArrayList<String> getSelectedStrings() {
        return selectedStrings;
    }





    public String str_remark;

    public String camera_lat;
    public String camera_long;
    public String camera_time;

    public String getCamera_lat() {
        return camera_lat;
    }

    public void setCamera_lat(String camera_lat) {
        this.camera_lat = camera_lat;
    }

    public String getCamera_long() {
        return camera_long;
    }

    public void setCamera_long(String camera_long) {
        this.camera_long = camera_long;
    }

    public String getCamera_time() {
        return camera_time;
    }

    public void setCamera_time(String camera_time) {
        this.camera_time = camera_time;
    }

    public String getStr_remark() {
        return str_remark;
    }

    public void setStr_remark(String str_remark) {
        this.str_remark = str_remark;
    }

    public static DataHolder_FactoryInspection getDataObject() {
        return dataObject;
    }

    public static void setDataObject(DataHolder_FactoryInspection dataObject) {
        DataHolder_FactoryInspection.dataObject = dataObject;
    }



    private String str_project_id;
    private String str_vendorName;
    private String str_utility;
    private String str_vendorResp;
    private String str_mainItem;
    private String str_lotStatus;

    public String getStr_mainItem() {
        return str_mainItem;
    }

    public void setStr_mainItem(String str_mainItem) {
        this.str_mainItem = str_mainItem;
    }

    public String getStr_lotStatus() {
        return str_lotStatus;
    }

    public void setStr_lotStatus(String str_lotStatus) {
        this.str_lotStatus = str_lotStatus;
    }

    public String getStr_project_id() {
        return str_project_id;
    }

    public void setStr_project_id(String str_project_id) {
        this.str_project_id = str_project_id;
    }

    public String getStr_vendorName() {
        return str_vendorName;
    }

    public void setStr_vendorName(String str_vendorName) {
        this.str_vendorName = str_vendorName;
    }

    public String getStr_utility() {
        return str_utility;
    }

    public void setStr_utility(String str_utility) {
        this.str_utility = str_utility;
    }

    public String getStr_vendorResp() {
        return str_vendorResp;
    }

    public void setStr_vendorResp(String str_vendorResp) {
        this.str_vendorResp = str_vendorResp;
    }


    public String getStringtkc_id() {
        return Stringtkc_id;
    }

    public void setStringtkc_id(String stringtkc_id) {
        Stringtkc_id = stringtkc_id;
    }

    public String getStringinspection_id() {
        return Stringinspection_id;
    }

    public void setStringinspection_id(String stringinspection_id) {
        Stringinspection_id = stringinspection_id;
    }

    private String Stringtkc_id;

    private String str_item;
    private String str_lotNo;
    private String str_inspectionGTPNo;
    private String str_quanttyIns;
    private String str_quantityPassed;

    private String str_po_no;
    private String str_invoice_no;

    public String getStr_po_no() {
        return str_po_no;
    }

    public void setStr_po_no(String str_po_no) {
        this.str_po_no = str_po_no;
    }

    public String getStr_invoice_no() {
        return str_invoice_no;
    }

    public void setStr_invoice_no(String str_invoice_no) {
        this.str_invoice_no = str_invoice_no;
    }

    public String getStr_item() {
        return str_item;
    }

    public void setStr_item(String str_item) {
        this.str_item = str_item;
    }

    public String getStr_lotNo() {
        return str_lotNo;
    }

    public void setStr_lotNo(String str_lotNo) {
        this.str_lotNo = str_lotNo;
    }

    public String getStr_inspectionGTPNo() {
        return str_inspectionGTPNo;
    }

    public void setStr_inspectionGTPNo(String str_inspectionGTPNo) {
        this.str_inspectionGTPNo = str_inspectionGTPNo;
    }

    public String getStr_quanttyIns() {
        return str_quanttyIns;
    }

    public void setStr_quanttyIns(String str_quanttyIns) {
        this.str_quanttyIns = str_quanttyIns;
    }

    public String getStr_quantityPassed() {
        return str_quantityPassed;
    }

    public void setStr_quantityPassed(String str_quantityPassed) {
        this.str_quantityPassed = str_quantityPassed;
    }




    private ArrayList<String> factoryselecteditem;
    public void setfactoryselecteditem(ArrayList<String> selectedStrings) {
        this.factoryselecteditem = selectedStrings;
    }

    public ArrayList<String> getfactoryselecteditem() {
        return factoryselecteditem;
    }

    public String factory_item;

    public String getFactory_item() {
        return factory_item;
    }

    public void setFactory_item(String factory_item) {
        this.factory_item = factory_item;
    }


    private String imgbitmap1;
    private String imgbitmap2;
    private String imgbitmap3;
    private String imgbitmap4;
    private String imgbitmap5;
    private String imglrgbitmap1;
    private String imglrgbitmap2;
    private String imglrgbitmap3;
    private String imglrgbitmap4;
    private String imglrgbitmap5;

    private String imageNmae1;
    private String imageNmae2;
    private String imageNmae3;
    private String imageNmae4;
    private String imageNmae5;

    public String getImageNmae1() {
        return imageNmae1;
    }

    public void setImageNmae1(String imageNmae1) {
        this.imageNmae1 = imageNmae1;
    }

    public String getImageNmae2() {
        return imageNmae2;
    }

    public void setImageNmae2(String imageNmae2) {
        this.imageNmae2 = imageNmae2;
    }

    public String getImageNmae3() {
        return imageNmae3;
    }

    public void setImageNmae3(String imageNmae3) {
        this.imageNmae3 = imageNmae3;
    }

    public String getImageNmae4() {
        return imageNmae4;
    }

    public void setImageNmae4(String imageNmae4) {
        this.imageNmae4 = imageNmae4;
    }

    public String getImageNmae5() {
        return imageNmae5;
    }

    public void setImageNmae5(String imageNmae5) {
        this.imageNmae5 = imageNmae5;
    }

    public void setImg1(String imgbitmap1) {
        this.imgbitmap1 = imgbitmap1;
    }
    public void setImg2(String imgbitmap2) {
        this.imgbitmap2 = imgbitmap2;
    }
    public void setImg3(String imgbitmap3) {
        this.imgbitmap3 = imgbitmap3;
    }
    public String getImg1() {
        return imgbitmap1;
    }
    public String getImg2() {
        return imgbitmap2;
    }
    public String getImg3() {
        return imgbitmap3;
    }

    public void setImg4(String imgbitmap4) {
        this.imgbitmap4 = imgbitmap4;
    }

    public void setImg5(String imgbitmap5) {
        this.imgbitmap5 = imgbitmap5;
    }

    public String getImg4() {
        return imgbitmap4;
    }

    public String getImg5() {
        return imgbitmap5;
    }



    public void setlrgImg1(String imglrgbitmap1) {
        this.imglrgbitmap1 = imglrgbitmap1;
    }

    public void setlrgImg2(String imglrgbitmap2) {
        this.imglrgbitmap2 = imglrgbitmap2;
    }

    public void setlrgImg3(String imglrgbitmap3) {
        this.imglrgbitmap3 = imglrgbitmap3;
    }

    public void setlrgImg4(String imglrgbitmap4) {
        this.imglrgbitmap4 = imglrgbitmap4;
    }

    public void setlrgImg5(String imglrgbitmap5) {
        this.imglrgbitmap5 = imglrgbitmap5;
    }

    public String getlrgImg1() {
        return imglrgbitmap1;
    }

    public String getlrgImg2() {
        return imglrgbitmap2;
    }

    public String getlrgImg3() {
        return imglrgbitmap3;
    }

    public String getlrgImg4() {
        return imglrgbitmap4;
    }

    public String getlrgImg5() {
        return imglrgbitmap5;
    }


    private String str_pole;
    private String str_dt;
    private String str_conductor;
    private String str_cable;
    private String str_metering;
    private String str_substation;
    private String common_item;

    public String getStr_scheme_id() {
        return str_scheme_id;
    }

    public void setStr_scheme_id(String str_scheme_id) {
        this.str_scheme_id = str_scheme_id;
    }

    public String getStr_supplier_id() {
        return str_supplier_id;
    }

    public void setStr_supplier_id(String str_supplier_id) {
        this.str_supplier_id = str_supplier_id;
    }

    public String getStr_supplier_rsp() {
        return str_supplier_rsp;
    }

    public void setStr_supplier_rsp(String str_supplier_rsp) {
        this.str_supplier_rsp = str_supplier_rsp;
    }

    public String getStr_other_rsp() {
        return str_other_rsp;
    }

    public void setStr_other_rsp(String str_other_rsp) {
        this.str_other_rsp = str_other_rsp;
    }

    private String str_scheme_id;
    private String str_supplier_id;
    private String str_supplier_rsp;
    private String str_other_rsp;
    private String Stringinspection_id;




    public String getCommon_item() {
        return common_item;
    }

    public void setCommon_item(String common_item) {
        this.common_item = common_item;
    }

    public String getStr_pole() {
        return str_pole;
    }

    public void setStr_pole(String str_pole) {
        this.str_pole = str_pole;
    }

    public String getStr_dt() {
        return str_dt;
    }

    public void setStr_dt(String str_dt) {
        this.str_dt = str_dt;
    }

    public String getStr_conductor() {
        return str_conductor;
    }

    public void setStr_conductor(String str_conductor) {
        this.str_conductor = str_conductor;
    }

    public String getStr_cable() {
        return str_cable;
    }

    public void setStr_cable(String str_cable) {
        this.str_cable = str_cable;
    }

    public String getStr_metering() {
        return str_metering;
    }

    public void setStr_metering(String str_metering) {
        this.str_metering = str_metering;
    }

    public String getStr_substation() {
        return str_substation;
    }

    public void setStr_substation(String str_substation) {
        this.str_substation = str_substation;
    }



    public void nullify_DataHolder_FactoryInspection_nextitem() {

        dataObject = null;

        str_item = null;
        str_lotNo = null;
        str_inspectionGTPNo = null;
        str_quanttyIns = null;
        str_quantityPassed = null;
        common_item = null;
        str_pole = null;
        str_dt = null;
        str_conductor = null;
        str_cable = null;
        str_metering = null;
        str_substation = null;

        str_lotStatus = null;
        str_mainItem = null;

        common_item = null;
        str_pole = null;
        str_dt = null;
        str_conductor = null;
        str_cable = null;
        str_metering = null;
        str_substation = null;



        imgbitmap1 = null;
        imgbitmap2 = null;
        imgbitmap3 = null;
        imgbitmap4 = null;
        imgbitmap5 = null;


        imglrgbitmap1 = null;
        imglrgbitmap2 = null;
        imglrgbitmap3 = null;
        imglrgbitmap4 = null;
        imglrgbitmap5 = null;

        imageNmae1= null;
        imageNmae2= null;
        imageNmae3= null;
        imageNmae4= null;
        imageNmae5= null;

    }


    public void nullify_DataHolder_FactoryInspection() {

        dataObject = null;

        str_project_id = null;

        str_scheme_id= null;
        str_supplier_id= null;
        str_supplier_rsp= null;
        str_other_rsp= null;
        Stringinspection_id= null;

        str_item = null;
        str_lotNo = null;
        str_inspectionGTPNo = null;
        str_quanttyIns = null;
        str_quantityPassed = null;

        common_item = null;
        str_pole = null;
        str_dt = null;
        str_conductor = null;
        str_cable = null;
        str_metering = null;
        str_substation = null;

        str_lotStatus = null;
        str_mainItem = null;

        imgbitmap1 = null;
        imgbitmap2 = null;
        imgbitmap3 = null;
        imgbitmap4 = null;
        imgbitmap5 = null;


        imglrgbitmap1 = null;
        imglrgbitmap2 = null;
        imglrgbitmap3 = null;
        imglrgbitmap4 = null;
        imglrgbitmap5 = null;

        imageNmae1= null;
        imageNmae2= null;
        imageNmae3= null;
        imageNmae4= null;
        imageNmae5= null;

    }



}
