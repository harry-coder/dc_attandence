package com.dcnine_attendance.authentication;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Debug;
import android.support.v4.app.ActivityCompat;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import com.dcnine_attendance.HTTPURLConnection;
import com.dcnine_attendance.MainSendServerActivity;
import com.dcnine_attendance.R;



import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class Authentication extends Activity {
	
	SessionManager session;
	String password;

	String response;
	public static String imeiSIM1 ;
	public static String imeiSIM2 ;


	String version;
	PackageInfo pInfo;
	String response_api="dd";

   String function="mobile_authentiction";


	private ProgressDialog pDialog;
	private JSONObject json;
	private int success=0;
	private HTTPURLConnection service;
	private String strname ="", strMobile ="",strAddress="";
	//Initialize webservice URL
	private String path = "http://attendance.feedbackinfra.com/dcnine_attendance/embc_app/mobile_authentiction";
	String token;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		setContentView(R.layout.authentication);

		System.out.println("123467");

		service=new HTTPURLConnection();

		session=new SessionManager(getApplicationContext());

//		if (Build.VERSION.SDK_INT >= 23) {
//			isStoragePermissionGranted();
//		}
		TelephonyManager tm = (TelephonyManager)
				getSystemService(Context.TELEPHONY_SERVICE);

		//isDualSimOrNot();
		try {
			//	cm = (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
			pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
		}  catch (PackageManager.NameNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		version=pInfo.versionName;
        if(session.isLoggedIn()){
			 StartFunction();
	      }else
        {
			StartFunction();
//			 ShowAlertagain();
	}
	}

	public boolean isStoragePermissionGranted() {
		if (Build.VERSION.SDK_INT >= 23) {
			if (getApplicationContext().checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
				return true;
			} else {
				ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_PHONE_STATE}, 1);
				return false;
			}
		} else {
			return true;
		}
	}


	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){


			Toast.makeText(getApplicationContext(), "Successfully Saved", Toast.LENGTH_SHORT).show();
			// Calling the same class
			isDualSimOrNot();
			recreate();
		}
		else
		{
			Toast.makeText(this, "The app was not allowed to write to your storage. Hence, it cannot function properly. Please consider granting it this permission", Toast.LENGTH_LONG).show();
		}
	}

	private void isDualSimOrNot(){
	    TelephonyInfo telephonyInfo = TelephonyInfo.getInstance(this);
	    imeiSIM1 = telephonyInfo.getImeiSIM1();
	    imeiSIM2 = telephonyInfo.getImeiSIM2();

	  }
	
	public void getConnectivityStatus(Context context) {
		ConnectivityManager cm = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);

		NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
		if (null != activeNetwork) {
			if(activeNetwork.getType() == ConnectivityManager.TYPE_WIFI){
			}	
			
		} else{
			
			}
		
	}	

	/*public void StartTask(){

		 CheckAPI();
	}*/


	public void StartFunction(){		
		Thread timer = new Thread()
		{
			public void run()
            
			{            
				try
                
				{                   
                   sleep(2000);
                   runOnUiThread(new Runnable() {
                    public void run() {
                         //splash.setImageResource(R.drawable.splash3);
                    }
                });                
                   sleep(2000);
                   runOnUiThread(new Runnable() {
                    public void run() {                    	                    	 
                    	 if(session.isLoggedIn()){	                  	
      	                    	 Intent intent=new Intent(getApplicationContext(), MainSendServerActivity.class);
 	              				startActivity(intent);
 	              				finish();	            				
            			}else{
							 System.out.println("12346789");
            				new PostDataTOServer().execute();
            			} 
                    }
                });                   
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        };
        timer.start();		
	}
	/*public void CheckAPI(){
		new PostDataTOServer().execute();
	}*/
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		Debug.stopMethodTracing();
		super.onDestroy();
	}
	private class PostDataTOServer extends AsyncTask<Void, Void, Void> {

		String response = "";
		//Create hashmap Object to send parameters to web service
		HashMap<String, String> postDataParams;
		@Override
		protected void onPreExecute() {
			super.onPreExecute();

			pDialog = new ProgressDialog(Authentication.this);
			pDialog.setMessage("Please wait...");
			pDialog.setCancelable(false);
			pDialog.show();
		}
		@Override
		protected Void doInBackground(Void... arg0) {
			postDataParams=new HashMap<String, String>();
			postDataParams.put("permit_id", "3003");
			postDataParams.put("project_id", "3003");
			postDataParams.put("mobile_date", "3003");
			postDataParams.put("latt", "3003");
			postDataParams.put("longg", "3003");
			postDataParams.put("distance_in", "3003");
			postDataParams.put("selfie_name", token);
			postDataParams.put("selfie", "3003");
			postDataParams.put("signature", "3003");

			//Call ServerData() method to call webservice and store result in response
			response= service.ServerData(path,postDataParams);
			Log.e("nitinbhati", "" + postDataParams);
			try {
				json = new JSONObject(response);
				//Get Values from JSONobject
				System.out.println("success=" + json.get("success"));
				success = json.getInt("success");

			} catch (JSONException e) {
				e.printStackTrace();
			}
			return null;
		}
		@Override
		protected void onPostExecute(Void result) {
			super.onPostExecute(result);
			if (pDialog.isShowing())
				pDialog.dismiss();
			if(success==1) {
				Toast.makeText(getApplicationContext(), "Employee Added successfully..!", Toast.LENGTH_LONG).show();
				Intent intent=new Intent(getApplicationContext(), MainSendServerActivity.class);
				startActivity(intent);
				finish();
			}
		}
	}


    public class BgAPI extends AsyncTask<String, String,String> {
		@Override
		protected String doInBackground(String... arg0) {
			// TODO Auto-generated method stub
			try{
					/*HttpClient httpclient = new DefaultHttpClient();
			        HttpPost httppost = new HttpPost("http://attendance.feedbackinfra.com/dcnine_attendance/embc_app/mobile_authentiction");
			        ResponseHandler<String> responseHandler = new BasicResponseHandler();
					response_api = httpclient.execute(httppost,responseHandler);*/
				}catch(Exception e){
					e.printStackTrace();
				}
			return response_api;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
        //	Log.e("response_api", ""+response_api);
			/*if(response_api.equalsIgnoreCase("dd")){
				Toast.makeText(getApplicationContext(), "Internet not connected / Server is not working", Toast.LENGTH_LONG).show();
				finish();
			}else{
				 response_api="dd";			
				 StartFunction();
			}*/
			StartFunction();
		}	
	}      
}